package actions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.chrome.ChromeDriver;

public class CustomValidityRequiredCheck {
	private static WebDriver driver;
    private static final String URL = "https://github.com/bonigarcia/webdrivermanager";

	public static void main(String[] args) {

		 WebDriverManager.chromedriver().setup();
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--headless", "--disable-gpu", "--window-size=1920,1200","--ignore-certificate-errors","--disable-extensions","--no-sandbox","--disable-dev-shm-usage");
		 driver = new ChromeDriver(options);
		driver.get("http://barterv2.herokuapp.com/signup");
		WebElement nullfieldprompt = new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(By.xpath("//body/div[@id='__nuxt']/div[@id='__layout']/main[1]/div[1]/div[1]/div[2]/form[1]/div[1]/div[1]/div[1]/div[1]/input[1]")));
		System.out.println(nullfieldprompt.getAttribute("validationMessage"));

		String expectedPrompt = "Please fill in this field.";
		String actualPrompt = nullfieldprompt.getAttribute("validationMessage");
		Assert.assertEquals(actualPrompt, expectedPrompt, "The Required Prompt Does Not Match The Expected Description");
		driver.quit();
	}
}







